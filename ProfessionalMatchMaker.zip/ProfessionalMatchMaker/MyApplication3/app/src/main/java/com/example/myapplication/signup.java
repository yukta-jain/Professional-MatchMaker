package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class signup extends AppCompatActivity {
    private Button signupButton;
    private EditText firstName;
    private EditText lastName;
    private EditText email;
    private EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        firstName=(EditText)findViewById(R.id.editText7);
        lastName=(EditText)findViewById(R.id.editText8);
        email=(EditText)findViewById(R.id.editText9);
        password=(EditText)findViewById(R.id.editText10);
        signupButton=(Button)findViewById(R.id.button5);
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 MainActivity();
            }
        });
    }

        public void MainActivity()
        {
            //TODO- Insert new record to database
            Intent intent= new Intent(this, MainActivity.class);
            startActivity(intent);
        }
}
