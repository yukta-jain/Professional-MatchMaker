package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class dashboard extends AppCompatActivity {

    private Button searchButton;
    private Button profileButton;
    private Button requestButton;
    private Button matchesButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        searchButton=(Button) findViewById(R.id.button7);
        profileButton=(Button) findViewById(R.id.button4);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                general_search();
            }
        });
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profile();
            }
        });
    }

    public void general_search(){
        Intent intent= new Intent(this, general_search.class);
        startActivity(intent);
    }

    public void profile(){
        Intent intent= new Intent(this, profile.class);
        startActivity(intent);
    }
}
